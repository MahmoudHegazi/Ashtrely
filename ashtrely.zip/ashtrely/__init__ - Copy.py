#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from flask import Flask, render_template, request, redirect, jsonify, url_for, flash
from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
#from database_setup import Base, Menu, Series, Movie, Item
from flask import session as login_session
import random
import string

# IMPORTS FOR THIS STEP
from oauth2client.client import flow_from_clientsecrets
from oauth2client.client import FlowExchangeError
import httplib2
import json
from flask import make_response
import requests
from tablib import Dataset



app = Flask(__name__)

# Show all restaurants
# Show all restaurants
@app.route('/')
@app.route('/bigtv/', methods=['GET', 'POST'])
def showIndex():
    return render_template("index.html")


@app.route('/upload', methods=['POST'])
def upload_file():
    # I used form data type which means there is a
    # "Content-Type: application/x-www-form-urlencoded"
    # header in my request
    raw_data = request.files['myfile'].read()  # In form data, I used "myfile" as key.
    dataset = Dataset().load(raw_data)
    #for side in dataset:
    #    #print(dataset)
    print(dataset[0])
    return jsonify(dataset.export('json'))


if __name__ == '__main__':
    app.secret_key = 'super_secret_key'
    app.debug = True
    app.run(host='0.0.0.0', port=8080, threaded=False)